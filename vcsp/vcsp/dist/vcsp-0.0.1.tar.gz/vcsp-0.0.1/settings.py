from colorama import init, Fore, Back, Style

#Foreground colour
green = Fore.GREEN 
black = Fore.BLACK
red = Fore.RED
yellow = Fore.YELLOW
blue = Fore.BLUE
magenta = Fore.MAGENTA
cyan = Fore.CYAN
white = Fore.WHITE